var regex = /\p{Script_Extensions=Makasar}/u;
