var regex = /[\u{1E2C0}-\u{1E2F9}\u{1E2FF}]/u;
