var regex = /(?:\uD83C[\uDDE6-\uDDFF])/;
